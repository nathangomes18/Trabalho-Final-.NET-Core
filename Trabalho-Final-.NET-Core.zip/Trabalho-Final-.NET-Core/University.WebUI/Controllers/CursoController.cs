using Microsoft.AspNetCore.Mvc;
using University.Application.Interfaces;
using University.Application.ViewModels;

namespace University.WebUI.Controllers
{
    public class CursoController : Controller
    {
        private readonly ICursoService _service;

        public CursoController(ICursoService service)
        {
            _service = service;
        }

        public IActionResult Index()
        {
            var cursos = _service.GetAll();
            return View(cursos);
        }

        public IActionResult Create() => View();

        [HttpPost]
        public IActionResult Create(CursoViewModel vm)
        {
            if (!ModelState.IsValid) return View(vm);
            _service.Add(vm);
            return RedirectToAction(nameof(Index));
        }

        public IActionResult Edit(int id)
        {
            var curso = _service.GetById(id);
            if (curso == null) return NotFound();
            return View(curso);
        }

        [HttpPost]
        public IActionResult Edit(CursoViewModel vm)
        {
            if (!ModelState.IsValid) return View(vm);
            _service.Update(vm);
            return RedirectToAction(nameof(Index));
        }

        public IActionResult Delete(int id)
        {
            var curso = _service.GetById(id);
            if (curso == null) return NotFound();
            return View(curso);
        }

        [HttpPost, ActionName("Delete")]
        public IActionResult DeleteConfirmed(int id)
        {
            _service.Delete(id);
            return RedirectToAction(nameof(Index));
        }
    }
}
