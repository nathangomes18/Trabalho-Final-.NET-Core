using Microsoft.AspNetCore.Mvc;
using University.Application.Interfaces;
using University.Application.ViewModels;
using System.Collections.Generic; // 👈 ADIÇÃO 1: Necessário para IEnumerable

namespace University.WebUI.Controllers
{
    public class AlunoController : Controller
    {
        private readonly IAlunoService _service;

        public AlunoController(IAlunoService service)
        {
            _service = service;
        }

        public IActionResult Index()
        {
            // Nota: Se você não quiser que o Index carregue todos os alunos inicialmente, 
            // basta retornar View() e deixar o AJAX carregar a lista inicial no frontend.
            var alunos = _service.GetAll();
            return View(alunos);
        }

        public IActionResult Create() => View();

        [HttpPost]
        public IActionResult Create(AlunoViewModel vm)
        {
            if (!ModelState.IsValid) return View(vm);
            _service.Add(vm);
            return RedirectToAction(nameof(Index));
        }

        public IActionResult Edit(int id)
        {
            var aluno = _service.GetById(id);
            if (aluno == null) return NotFound();
            return View(aluno);
        }

        [HttpPost]
        public IActionResult Edit(AlunoViewModel vm)
        {
            if (!ModelState.IsValid) return View(vm);
            _service.Update(vm);
            return RedirectToAction(nameof(Index));
        }

        public IActionResult Delete(int id)
        {
            var aluno = _service.GetById(id);
            if (aluno == null) return NotFound();
            return View(aluno);
        }

        [HttpPost, ActionName("Delete")]
        public IActionResult DeleteConfirmed(int id)
        {
            _service.Delete(id);
            return RedirectToAction(nameof(Index));
        }

        // ADIÇÃO 2: NOVO MÉTODO PARA BUSCA DINÂMICA COM AJAX (Requisito 7)
        [HttpGet]
        public IActionResult Search(string searchTerm)
        {
            IEnumerable<AlunoViewModel> alunos;

            if (string.IsNullOrWhiteSpace(searchTerm))
            {
                // Se o campo de busca estiver vazio (como no carregamento inicial), retorna todos
                alunos = _service.GetAll();
            }
            else
            {
                // Chama o método Search do IAlunoService
                alunos = _service.Search(searchTerm);
            }

            // Retorna a Partial View com a lista filtrada
            // O nome "_AlunoListPartial" é o arquivo que será atualizado pelo AJAX no frontend
            return PartialView("_AlunoListPartial", alunos);
        }
    }
}