using Microsoft.AspNetCore.Mvc;
using University.Application.Interfaces;
using University.Application.ViewModels;
using System;

namespace University.WebUI.Controllers
{
    public class MatriculaController : Controller
    {
        private readonly IMatriculaService _service;

        public MatriculaController(IMatriculaService service)
        {
            _service = service;
        }

        public IActionResult Index()
        {
            var matriculas = _service.GetAll();
            return View(matriculas);
        }

        public IActionResult Create()
        {
            var viewModel = new MatriculaViewModel
            {
                DataMatricula = DateTime.Now
            };
            return View(viewModel);
        }

        [HttpPost]
        public IActionResult Create(MatriculaViewModel vm)
        {
            if (!ModelState.IsValid)
                return View(vm);

            _service.Add(vm);
            return RedirectToAction(nameof(Index));
        }

        public IActionResult Edit(int id)
        {
            var matricula = _service.GetById(id);
            if (matricula == null)
                return NotFound();

            return View(matricula);
        }

        [HttpPost]
        public IActionResult Edit(MatriculaViewModel vm)
        {
            if (!ModelState.IsValid)
                return View(vm);

            _service.Update(vm);
            return RedirectToAction(nameof(Index));
        }

        public IActionResult Delete(int id)
        {
            var matricula = _service.GetById(id);
            if (matricula == null)
                return NotFound();

            return View(matricula);
        }

        [HttpPost, ActionName("Delete")]
        public IActionResult DeleteConfirmed(int id)
        {
            _service.Delete(id);
            return RedirectToAction(nameof(Index));
        }
    }
}
