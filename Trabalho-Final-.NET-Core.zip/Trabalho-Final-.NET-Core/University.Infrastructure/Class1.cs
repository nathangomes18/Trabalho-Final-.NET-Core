﻿namespace University.Infrastructure;

public class Class1
{

}
