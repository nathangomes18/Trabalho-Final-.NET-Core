using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using University.Domain.Entities; // Importa as entidades do Domínio

namespace University.Infrastructure.Configurations
{
    // A classe implementa a interface IEntityTypeConfiguration para a entidade Matricula
    public class MatriculaConfiguration : IEntityTypeConfiguration<Matricula>
    {
        public void Configure(EntityTypeBuilder<Matricula> builder)
        {
            // 1. Define a chave primária composta (Requisito 2: Chave Explícita)
            // Assumo que você adicionou as propriedades de navegação no Domínio,
            // caso contrário, o WithMany() pode falhar.
            builder.HasKey(m => new { m.AlunoId, m.CursoId });

            // 2. Configura o relacionamento N:1 com Aluno
            builder.HasOne(m => m.Aluno)
                   // .WithMany(a => a.Matriculas) // Descomente se adicionar a propriedade de navegação
                   .WithMany() // Usado se você não quiser ou não puder adicionar a coleção em Aluno
                   .HasForeignKey(m => m.AlunoId) // Chave Estrangeira explícita (Requisito 2)
                   .IsRequired();

            // 3. Configura o relacionamento N:1 com Curso
            builder.HasOne(m => m.Curso)
                   // .WithMany(c => c.Matriculas) // Descomente se adicionar a propriedade de navegação
                   .WithMany() // Usado se você não quiser ou não puder adicionar a coleção em Curso
                   .HasForeignKey(m => m.CursoId) // Chave Estrangeira explícita (Requisito 2)
                   .IsRequired();
            
            // 4. Mapeamento da coluna DataMatricula para tipo de dado específico, se necessário
            builder.Property(m => m.DataMatricula).IsRequired().HasColumnType("datetime2");
        }
    }
}