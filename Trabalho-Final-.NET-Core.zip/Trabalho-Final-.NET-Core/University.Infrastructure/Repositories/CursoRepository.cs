using System.Collections.Generic;
using System.Linq;
using University.Domain.Entities;
using University.Domain.Interfaces;
using University.Infrastructure.Data;

namespace University.Infrastructure.Repositories
{
    public class CursoRepository : ICursoRepository
    {
        private readonly ApplicationDbContext _context;

        public CursoRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public void Add(Curso curso) => _context.Cursos.Add(curso);
        public void Update(Curso curso) => _context.Cursos.Update(curso);
        public void Delete(int id)
        {
            var curso = GetById(id);
            if (curso != null) _context.Cursos.Remove(curso);
        }

        public Curso GetById(int id) => _context.Cursos.Find(id);
        public IEnumerable<Curso> GetAll() => _context.Cursos.ToList();
    }
}
