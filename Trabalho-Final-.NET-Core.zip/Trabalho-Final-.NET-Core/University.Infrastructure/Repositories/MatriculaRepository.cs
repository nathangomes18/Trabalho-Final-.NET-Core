using System.Collections.Generic;
using System.Linq;
using University.Domain.Entities;
using University.Domain.Interfaces;
using University.Infrastructure.Data;

namespace University.Infrastructure.Repositories
{
    public class MatriculaRepository : IMatriculaRepository
    {
        private readonly ApplicationDbContext _context;

        public MatriculaRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public void Add(Matricula matricula) => _context.Matriculas.Add(matricula);
        public void Update(Matricula matricula) => _context.Matriculas.Update(matricula);
        public void Delete(int id)
        {
            var matricula = GetById(id);
            if (matricula != null) _context.Matriculas.Remove(matricula);
        }

        public Matricula GetById(int id) => _context.Matriculas.Find(id);
        public IEnumerable<Matricula> GetAll() => _context.Matriculas.ToList();
    }
}
