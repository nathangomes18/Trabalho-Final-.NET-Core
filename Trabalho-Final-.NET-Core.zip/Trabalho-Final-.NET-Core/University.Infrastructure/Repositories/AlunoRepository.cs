using System.Collections.Generic;
using System.Linq; // Necessário para usar Where()
using University.Domain.Entities;
using University.Domain.Interfaces;
using University.Infrastructure.Data;

namespace University.Infrastructure.Repositories
{
    public class AlunoRepository : IAlunoRepository
    {
        private readonly ApplicationDbContext _context;

        public AlunoRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public void Add(Aluno aluno) => _context.Alunos.Add(aluno);
        public void Update(Aluno aluno) => _context.Alunos.Update(aluno);
        public void Delete(int id)
        {
            var aluno = GetById(id);
            if (aluno != null) _context.Alunos.Remove(aluno);
        }

        public Aluno GetById(int id) => _context.Alunos.Find(id);
        public IEnumerable<Aluno> GetAll() => _context.Alunos.ToList();

        // IMPLEMENTAÇÃO DO MÉTODO DE BUSCA (Requisito 7)
        public IEnumerable<Aluno> Search(string searchTerm)
        {
            if (string.IsNullOrWhiteSpace(searchTerm))
            {
                // Retorna todos os alunos se o termo de busca estiver vazio
                return _context.Alunos.ToList();
            }

            // Busca por Nome ou CPF que contenham o termo de busca
            return _context.Alunos
                           .Where(a => a.Nome.Contains(searchTerm) || a.CPF.Contains(searchTerm))
                           .ToList();
        }
    }
}