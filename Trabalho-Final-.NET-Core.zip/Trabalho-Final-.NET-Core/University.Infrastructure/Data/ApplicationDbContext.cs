using Microsoft.EntityFrameworkCore;
using University.Domain.Entities;

namespace University.Infrastructure.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options) { }

        public DbSet<Aluno> Alunos { get; set; }
        public DbSet<Curso> Cursos { get; set; }
        public DbSet<Matricula> Matriculas { get; set; }

        // Adição do OnModelCreating para aplicar a Configuração Explícita (Requisito 2)
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Esta linha busca e aplica todas as classes que implementam IEntityTypeConfiguration 
            // que estão no mesmo assembly (University.Infrastructure), incluindo a MatriculaConfiguration.
            modelBuilder.ApplyConfigurationsFromAssembly(typeof(ApplicationDbContext).Assembly);

            base.OnModelCreating(modelBuilder);
        }
    }
}