using System.Collections.Generic;
using System.Linq;
using University.Application.Interfaces;
using University.Application.ViewModels;
using University.Domain.Entities;
using University.Domain.Interfaces;

namespace University.Application.Services
{
    public class MatriculaService : IMatriculaService
    {
        private readonly IMatriculaRepository _repository;

        public MatriculaService(IMatriculaRepository repository)
        {
            _repository = repository;
        }

        public void Add(MatriculaViewModel vm)
        {
            var matricula = new Matricula
            {
                AlunoId = vm.AlunoId,
                CursoId = vm.CursoId,
                DataMatricula = vm.DataMatricula
            };
            _repository.Add(matricula);
        }


        public void Update(MatriculaViewModel vm)
        {
            var matricula = new Matricula
            {
                Id = vm.Id,
                AlunoId = vm.AlunoId,
                CursoId = vm.CursoId,
                DataMatricula = vm.DataMatricula
            };
            _repository.Update(matricula);
        }

        public void Delete(int id) => _repository.Delete(id);

        public MatriculaViewModel GetById(int id)
        {
            var m = _repository.GetById(id);
            if (m == null) return null;

            return new MatriculaViewModel
            {
                Id = m.Id,
                AlunoId = m.AlunoId,
                CursoId = m.CursoId,
                DataMatricula = m.DataMatricula
            };
        }

        public IEnumerable<MatriculaViewModel> GetAll()
        {
            return _repository.GetAll().Select(m => new MatriculaViewModel
            {
                Id = m.Id,
                AlunoId = m.AlunoId,
                CursoId = m.CursoId,
                DataMatricula = m.DataMatricula
            });
        }
    }
}
