using System.Collections.Generic;
using System.Linq;
using University.Application.Interfaces;
using University.Application.ViewModels;
using University.Domain.Entities;
using University.Domain.Interfaces;

namespace University.Application.Services
{
    public class CursoService : ICursoService
    {
        private readonly ICursoRepository _repository;

        public CursoService(ICursoRepository repository)
        {
            _repository = repository;
        }

        public void Add(CursoViewModel vm)
        {
            var curso = new Curso
            {
                Nome = vm.Nome,
                CargaHoraria = vm.CargaHoraria
            };
            _repository.Add(curso);
        }

        public void Update(CursoViewModel vm)
        {
            var curso = new Curso
            {
                Id = vm.Id,
                Nome = vm.Nome,
                CargaHoraria = vm.CargaHoraria
            };
            _repository.Update(curso);
        }

        public void Delete(int id)
        {
            _repository.Delete(id);
        }

        public CursoViewModel GetById(int id)
        {
            var curso = _repository.GetById(id);
            if (curso == null) return null;

            return new CursoViewModel
            {
                Id = curso.Id,
                Nome = curso.Nome,
                CargaHoraria = curso.CargaHoraria
            };
        }

        public IEnumerable<CursoViewModel> GetAll()
        {
            return _repository.GetAll().Select(curso => new CursoViewModel
            {
                Id = curso.Id,
                Nome = curso.Nome,
                CargaHoraria = curso.CargaHoraria
            });
        }
    }
}
