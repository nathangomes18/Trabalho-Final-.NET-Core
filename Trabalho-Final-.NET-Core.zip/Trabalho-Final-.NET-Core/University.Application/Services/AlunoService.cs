// Em University.Application/Services/AlunoService.cs

using Mapster;
using University.Application.Interfaces;
using University.Application.ViewModels;
using University.Domain.Entities;
using University.Domain.Interfaces;
using System.Collections.Generic;
using System.Linq;

namespace University.Application.Services
{
    public class AlunoService : IAlunoService
    {
        private readonly IAlunoRepository _repository;

        public AlunoService(IAlunoRepository repository)
        {
            _repository = repository;
        }

        // Métodos CRUD existentes
        public void Add(AlunoViewModel vm) => _repository.Add(vm.Adapt<Aluno>());
        public void Update(AlunoViewModel vm) => _repository.Update(vm.Adapt<Aluno>());
        public void Delete(int id) => _repository.Delete(id);
        public AlunoViewModel GetById(int id) => _repository.GetById(id).Adapt<AlunoViewModel>();
        public IEnumerable<AlunoViewModel> GetAll() => _repository.GetAll().Adapt<IEnumerable<AlunoViewModel>>();

        // ADIÇÃO 2: Implementação do Search (Resolve o erro CS0535)
        public IEnumerable<AlunoViewModel> Search(string searchTerm)
        {
            var alunos = _repository.Search(searchTerm);
            return alunos.Adapt<IEnumerable<AlunoViewModel>>();
        }
    }
}