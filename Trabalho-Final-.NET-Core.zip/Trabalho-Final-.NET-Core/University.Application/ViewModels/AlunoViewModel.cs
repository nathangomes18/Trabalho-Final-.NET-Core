using System;
using System.ComponentModel.DataAnnotations;
using University.Domain.ValidationAttributes; // NECESSÁRIO para usar os atributos customizados

namespace University.Application.ViewModels
{
    public class AlunoViewModel
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "O campo Nome é obrigatório.")]
        [StringLength(100, ErrorMessage = "O Nome deve ter no máximo 100 caracteres.")]
        [NomeMaiusculo(ErrorMessage = "O Nome deve iniciar com letra maiúscula.")] // 👈 2ª VALIDAÇÃO PERSONALIZADA
        public string Nome { get; set; }

        [Required(ErrorMessage = "O campo CPF é obrigatório.")]
        // Validação padrão do CPF (baseada na Entidade)
        [RegularExpression(@"\d{11}", ErrorMessage = "CPF deve conter 11 dígitos.")]
        public string CPF { get; set; }

        [Required(ErrorMessage = "A Data de Nascimento é obrigatória.")]
        // 1ª VALIDAÇÃO PERSONALIZADA: Exige no mínimo 16 anos
        [IdadeMinima(16, ErrorMessage = "A idade mínima para matrícula é de 16 anos.")]
        public DateTime DataNascimento { get; set; }
    }
}