using System;
using System.ComponentModel.DataAnnotations;

namespace University.Application.ViewModels
{
    public class MatriculaViewModel
    {
        public int Id { get; set; }

        [Required]
        public int AlunoId { get; set; }

        [Required]
        public int CursoId { get; set; }

        [Required]
        public DateTime DataMatricula { get; set; }
    }
}
