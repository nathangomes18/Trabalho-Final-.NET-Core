using System.ComponentModel.DataAnnotations;

namespace University.Application.ViewModels
{
    public class CursoViewModel
    {
        public int Id { get; set; }

        [Required]
        [StringLength(100)]
        public string Nome { get; set; }

        [Range(1, 1000)]
        public int CargaHoraria { get; set; }
    }
}
