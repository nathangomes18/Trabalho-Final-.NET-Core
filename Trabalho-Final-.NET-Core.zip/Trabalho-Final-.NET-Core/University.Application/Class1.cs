﻿namespace University.Application;

public class Class1
{

}
