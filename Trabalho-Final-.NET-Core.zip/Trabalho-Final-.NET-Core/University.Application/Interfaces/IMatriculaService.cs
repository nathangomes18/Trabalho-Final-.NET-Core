using System.Collections.Generic;
using University.Application.ViewModels;

namespace University.Application.Interfaces
{
    public interface IMatriculaService
    {
        MatriculaViewModel GetById(int id);
        IEnumerable<MatriculaViewModel> GetAll();
        void Add(MatriculaViewModel matricula);
        void Update(MatriculaViewModel matricula);
        void Delete(int id);
    }
}
