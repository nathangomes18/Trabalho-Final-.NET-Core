using System.Collections.Generic;
using University.Application.ViewModels;

namespace University.Application.Interfaces
{
    public interface IAlunoService
    {
        // CRUD Básico
        AlunoViewModel GetById(int id);
        IEnumerable<AlunoViewModel> GetAll();
        void Add(AlunoViewModel aluno);
        void Update(AlunoViewModel aluno);
        void Delete(int id);
        
        // NOVO MÉTODO PARA BUSCA DINÂMICA (Requisito 7)
        IEnumerable<AlunoViewModel> Search(string searchTerm);
    }
}