using System.Collections.Generic;
using University.Application.ViewModels;

namespace University.Application.Interfaces
{
    public interface ICursoService
    {
        CursoViewModel GetById(int id);
        IEnumerable<CursoViewModel> GetAll();
        void Add(CursoViewModel curso);
        void Update(CursoViewModel curso);
        void Delete(int id);
    }
}
