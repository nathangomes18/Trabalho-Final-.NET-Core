﻿namespace University.Domain;

public class Class1
{

}
