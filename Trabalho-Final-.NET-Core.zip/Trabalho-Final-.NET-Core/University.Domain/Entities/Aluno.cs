using System;
using System.ComponentModel.DataAnnotations;

namespace University.Domain.Entities
{
    public class Aluno
    {
        public int Id { get; set; }

        [Required]
        [StringLength(100)]
        public string Nome { get; set; }

        [Required]
        [RegularExpression(@"\d{11}", ErrorMessage = "CPF deve conter 11 dígitos.")]
        public string CPF { get; set; }

        [Required]
        public DateTime DataNascimento { get; set; }
    }
}
