using System.ComponentModel.DataAnnotations;

namespace University.Domain.Entities
{
    public class Curso
    {
        public int Id { get; set; }

        [Required]
        [StringLength(100)]
        public string Nome { get; set; }

        [Range(1, 1000)]
        public int CargaHoraria { get; set; }
    }
}
