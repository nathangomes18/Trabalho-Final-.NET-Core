// Em University.Domain/Entities/Matricula.cs (Conteúdo corrigido)

using System;
using System.ComponentModel.DataAnnotations;

namespace University.Domain.Entities
{
    public class Matricula
    {
        public int Id { get; set; }

        [Required]
        public int AlunoId { get; set; }

        [Required]
        public int CursoId { get; set; }

        [Required]
        public DateTime DataMatricula { get; set; }

        // ADIÇÃO OBRIGATÓRIA
        public Aluno Aluno { get; set; } 
        public Curso Curso { get; set; }
    }
}