using System.Collections.Generic;
using University.Domain.Entities;

namespace University.Domain.Interfaces
{
    public interface ICursoRepository
    {
        Curso GetById(int id);
        IEnumerable<Curso> GetAll();
        void Add(Curso curso);
        void Update(Curso curso);
        void Delete(int id);
    }
}
