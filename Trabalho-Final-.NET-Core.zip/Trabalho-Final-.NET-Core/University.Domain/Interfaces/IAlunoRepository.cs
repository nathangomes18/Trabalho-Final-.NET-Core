// University.Domain/Interfaces/IAlunoRepository.cs
using System.Collections.Generic;
using University.Domain.Entities; 

namespace University.Domain.Interfaces
{
    public interface IAlunoRepository
    {
        // Métodos de CRUD
        Aluno GetById(int id);
        IEnumerable<Aluno> GetAll();
        void Add(Aluno aluno);
        void Update(Aluno aluno);
        void Delete(int id);

        // REQUISITO 7: Busca
        IEnumerable<Aluno> Search(string searchTerm);
    }
}