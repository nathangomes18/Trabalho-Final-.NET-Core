using System.Collections.Generic;
using University.Domain.Entities;

namespace University.Domain.Interfaces
{
    public interface IMatriculaRepository
    {
        Matricula GetById(int id);
        IEnumerable<Matricula> GetAll();
        void Add(Matricula matricula);
        void Update(Matricula matricula);
        void Delete(int id);
    }
}
