using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace University.Domain.ValidationAttributes
{
    public class NomeMaiusculoAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (value is string nome && !string.IsNullOrEmpty(nome))
            {
                // Verifica se a primeira letra é maiúscula
                if (char.IsLower(nome.First()))
                {
                    return new ValidationResult(ErrorMessage ?? "O Nome deve iniciar com uma letra maiúscula.");
                }
            }
            // Retorna sucesso para null/vazio, pois [Required] deve lidar com isso
            return ValidationResult.Success;
        }
    }
}