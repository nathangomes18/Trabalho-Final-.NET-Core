using System;
using System.ComponentModel.DataAnnotations;

namespace University.Domain.ValidationAttributes
{
    public class IdadeMinimaAttribute : ValidationAttribute
    {
        private readonly int _idadeMinima;

        public IdadeMinimaAttribute(int idadeMinima)
        {
            _idadeMinima = idadeMinima;
        }

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (value is DateTime dataNascimento)
            {
                var hoje = DateTime.Today;
                var idade = hoje.Year - dataNascimento.Year;
                
                // Ajusta a idade se o aniversário ainda não ocorreu
                if (dataNascimento.Date > hoje.AddYears(-idade))
                {
                    idade--;
                }

                if (idade < _idadeMinima)
                {
                    return new ValidationResult(ErrorMessage ?? $"O aluno deve ter no mínimo {_idadeMinima} anos.");
                }
            }
            return ValidationResult.Success;
        }
    }
}